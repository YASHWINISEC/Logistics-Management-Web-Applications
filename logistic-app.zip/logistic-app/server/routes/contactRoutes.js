const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const {
  submitContactForm,
  getContacts,
  updateContactStatus
} = require('../controllers/contactController');

// Validation rules for contact form
const contactValidation = [
  body('name').notEmpty().withMessage('Name is required').trim(),
  body('email').isEmail().withMessage('Please enter a valid email').normalizeEmail(),
  body('phone').optional().trim(),
  body('company').optional().trim(),
  body('message').notEmpty().withMessage('Message is required').trim()
];

// Public route
router.post('/', contactValidation, submitContactForm);

// Admin routes (in production, add authentication middleware)
router.get('/', getContacts);
router.put('/:id', updateContactStatus);

module.exports = router;